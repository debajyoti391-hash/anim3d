import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";

export type Caption = { text: string; startMs: number; endMs: number };

export const Captions = ({ captions }: { captions: Caption[] }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const nowMs = (frame / fps) * 1000;
  const active = captions.find((c) => nowMs >= c.startMs && nowMs < c.endMs);
  if (!active) return null;
  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 90 }}>
      <div style={{ color: "white", fontSize: 64, fontWeight: 800, fontFamily: "sans-serif",
        textShadow: "0 4px 12px rgba(0,0,0,0.8)", textAlign: "center", maxWidth: 1500 }}>
        {active.text}
      </div>
    </AbsoluteFill>
  );
};
