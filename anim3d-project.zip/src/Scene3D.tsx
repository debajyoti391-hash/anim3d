import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { Captions, type Caption } from "./Captions";

// Three.js object: everything is driven by the frame number, so renders are exact.
const SpinningCube = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const scale = interpolate(frame, [0, 30], [0, 1], { extrapolateRight: "clamp" });
  return (
    <mesh rotation={[t * 0.8, t * 1.2, 0]} scale={scale}>
      <boxGeometry args={[2, 2, 2]} />
      <meshStandardMaterial color="#4f8cff" metalness={0.3} roughness={0.35} />
    </mesh>
  );
};

// Edit these to change on-screen captions (times in milliseconds).
const captions: Caption[] = [
  { text: "Hello from Three.js", startMs: 0, endMs: 2000 },
  { text: "Captions powered by Remotion", startMs: 2000, endMs: 5000 },
];

export const Scene3D = () => {
  const { width, height } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: "#0b0f1a" }}>
      <ThreeCanvas width={width} height={height} camera={{ position: [0, 0, 6], fov: 50 }}>
        <ambientLight intensity={0.6} />
        <pointLight position={[5, 5, 5]} intensity={80} />
        <SpinningCube />
      </ThreeCanvas>
      <Captions captions={captions} />
      {/* Drop an audio file into /public and uncomment: */}
      {/* <Audio src={staticFile("voiceover.mp3")} /> */}
    </AbsoluteFill>
  );
};
