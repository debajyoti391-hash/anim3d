# 3D Animation Stack: Three.js + Remotion

1. Install Node.js (https://nodejs.org, the LTS version).
2. Open a terminal in this folder and run:  npm install
3. Preview:  npm run studio
4. Export video:  npm run render   (creates out/video.mp4)

Edit src/Scene3D.tsx for the 3D scene and captions.
Put audio files in the public/ folder.
