import { Config } from "@remotion/cli/config";
Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// Needed so Three.js scenes render correctly when exporting
Config.setChromiumOpenGlRenderer("angle");
